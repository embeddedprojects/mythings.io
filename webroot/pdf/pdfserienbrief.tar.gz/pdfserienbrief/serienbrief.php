<?php
$rootpath = str_replace('/serienbrief.php','',__FILE__);
define('ROOTPATH',$rootpath);

$includePath = ini_get('include_path');
$includePath.= PATH_SEPARATOR.ROOTPATH.DIRECTORY_SEPARATOR.'lib';
ini_set('include_path', $includePath);
ini_set("max_execution_time", 0); //script unendlich lange ausführen

require_once('fpdi.php');

$mysql_host = 'localhost';
$mysql_database = 'serienbrief';
$mysql_username = 'root';
$mysql_password = '';
$mysql_table = 'addresses';

class serienbrief_pdf extends FPDI { 
    var $recipients = array(); 
    var $template = 'vorlage.pdf';
    var $posX = 24;
    var $posY = 51;
    var $font = 'Arial';
    var $fontSize = 10;
    var $lineHeight = 4;
    function addRecipient($vorname,$nachname,$strasse,$plz,$ort,$land){
	$this->recipients[]=array('vorname'=>$vorname,'nachname'=>$nachname,'strasse'=>$strasse,'plz'=>$plz,'ort'=>$ort,'land'=>$land);
    }	 
    function getRecipientLabel($recipientNr){
	$result = $this->recipients[$recipientNr]['vorname']." ".$this->recipients[$recipientNr]['nachname']."\n";
	$result .= $this->recipients[$recipientNr]['strasse']."\n\n";
	$result .= $this->recipients[$recipientNr]['plz']." ".$this->recipients[$recipientNr]['ort']."\n";
	$result .= $this->recipients[$recipientNr]['land'];
	return $result;
    }
    function createSerienbrief() { 
        $pagecount = $this->setSourceFile($this->template); 
	for ($recipient=0;$recipient<count($this->recipients);$recipient++){        
		for ($i = 1; $i <= $pagecount; $i++) { 
		  $tplidx = $this->ImportPage($i); 
		  $s = $this->getTemplatesize($tplidx); 
		  $this->AddPage($s['h'] > $s['w'] ? 'P' : 'L'); 
		  $this->useTemplate($tplidx); 
		  if($i==1){
			// now write some text above the imported page
			$this->SetFont($this->font);
			$this->SetFontSize($this->fontSize);
			$this->SetXY($this->posX, $this->posY);
			$this->MultiCell(0, $this->lineHeight, $this->getRecipientLabel($recipient));
		  }
		}
	} 
    } 

}
	//MySQL Abfrage durchführen
	$connection=mysql_connect($mysql_host, $mysql_username, $mysql_password) 
		or die("Verbindungsversuch zur Datenbank fehlgeschlagen");
	mysql_select_db($mysql_database, $connection) 
		or die("Konnte die Datenbank nicht waehlen.");
	$sql = "SELECT * FROM $mysql_table WHERE printed='checked'";
	$result = mysql_query($sql) or die(mysql_error());
	mysql_close($connection); 
	 
	$pdf =& new serienbrief_pdf(); 
	$nextRow = mysql_fetch_array($result);
	while ($nextRow){
		$pdf->addRecipient($nextRow['vorname'],$nextRow['nachname'],$nextRow['strasse'],$nextRow['plz'],$nextRow['ort'],$nextRow['land']);
		$nextRow = mysql_fetch_array($result);	
	}
	$pdf->createSerienbrief(); 
	 
	$pdf->Output('ausgabe/serienbrief.pdf', 'F'); 

?>
